Introduction
------------

Non- Invasive and Non-Detectable Server Reconnaisance Scanner - by th3j35t3r

OSINT at it's finest.

Bypassing API limitations and currently detecting 6500+ vulnerable server paths/files - without ever touching the target server. Very good for getting hold of intel on a given domain (example.com). The intel gained serves both as actionable in the sense that it could be directly used to help root a box, while at the same time giving a good overview of stuff thats present on the box and where it is within the directory structure.

FoxOne Scanner creates a report and dumps it on your Desktop.

Features:

* Anti False-Positive Measures
* Bot Stealth Measures
* Modular Framework for easy importing of new modules.

NOTE: I might redo this in perl in order to take advantage of MultiThreading (make it run faster).


Requirements
------------

MySQL Server
PHP5
PHP-GD Library
PHP-MySQL
Festival (text to speech)

Intallation
-----------

1). Create a MySQL database anywhere (localhost is fine).
2). Import 'foxone.sql' into the database you just created.
3). Edit 'foxone' adding the details of the database you just setup.

Usage
-----

foxone <domain.com>





