#!/bin/bash
# Script to change all Cpanel user's password at once and save them in a file
# 
#
# Hardeep Singh (cyb3r gladiat0r)
#            The cPanel Exploiter (cSploit)             
#       Written by: Hardeep Singh (cyb3r gladiat0r)     
#         Development Team: Infi-Zeal                   
#                  Version: 1.0                         
#        Report bugs to: cyb3r.gladiat0r@gmail.com      
#      Subscribe me at Facebook: www.fb.com/h4rdeep     
#   Follow me on Twitter:www.twitter.com/cyb3rgladiat0r 
#
scriptversion=1.0
#source depend/updater.sh

function f_echobreak () {
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
	echo
}

function f_menu () {
f_echobreak
today=$(date +"%Y-%m-%d")
timenow=$(date +"%r")
function f_banner1 () {
echo '                                     
                   _____       _       _ _   
                  / ____|     | |     (_) |  
              ___| (___  _ __ | | ___  _| |_ 
             / __|\___ \| `_ \| |/ _ \| | __|
            | (__ ____) | |_) | | (_) | | |_ 
             \___|_____/| .__/|_|\___/|_|\__|
                        | |                  
                        |_|                  
'
sleep 1
}
function f_banner2 () {
echo '
                  ________       ______     __________ 
            ________  ___/__________  /________(_)_  /_
            _  ___/____ \___  __ \_  /_  __ \_  /_  __/
            / /__ ____/ /__  /_/ /  / / /_/ /  / / /_  
            \___/ /____/ _  .___//_/  \____//_/  \__/  
                         /_/                           
'
sleep 1
}
function f_banner3 () {
echo "
[0;1;30;96m
                                    d8b           d8,        
                                      88P          '8P    d8P  
                                     d88               d888888P
             d8888b .d888b,?88,.d88b,888   d8888b   88b  ?88'  
            d8P' 'P ?8b,   '?88'  ?88?88  d8P' ?88  88P  88P   
            88b       '?8b   88b  d8P 88b 88b  d88 d88   88b   
            '?888P''?888P'   888888P'  88b'?8888P'd88'   '?8b  
                             88P'                              
                            d88                                
                            ?8P                      [0;0m          
"
sleep 1
}
function f_banner4 () {
echo '
             ______   ______   ______   __       ______    ________  _________ 
            /_____/\ /_____/\ /_____/\ /_/\     /_____/\  /_______/\/________/\
            \:::__\/ \::::_\/_\:::_ \ \\:\ \    \:::_ \ \ \__.::._\/\__.::.__\/
             \:\ \  __\:\/___/\\:(_) \ \\:\ \    \:\ \ \ \   \::\ \    \::\ \  
              \:\ \/_/\\_::._\:\\: ___\/ \:\ \____\:\ \ \ \  _\::\ \__  \::\ \ 
               \:\_\ \ \ /____\:\\ \ \    \:\/___/\\:\_\ \ \/__\::\__/\  \::\ \
                \_____\/ \_____\/ \_\/     \_____\/ \_____\/\________\/   \__\/

'
sleep 1
}
function f_banner5 () {
echo '
[0;31m
           @@@@@@@   @@@@@@   @@@@@@@   @@@        @@@@@@   @@@  @@@@@@@
          @@@@@@@@  @@@@@@@   @@@@@@@@  @@@       @@@@@@@@  @@@  @@@@@@@
          !@@       !@@       @@!  @@@  @@!       @@!  @@@  @@!    @@!  
          !@!       !@!       !@!  @!@  !@!       !@!  @!@  !@!    !@!  [0;33m
          !@!       !!@@!!    @!@@!@!   @!!       @!@  !@!  !!@    @!!  
          !!!        !!@!!!   !!@!!!    !!!       !@!  !!!  !!!    !!!  
          :!!            !:!  !!:       !!:       !!:  !!!  !!:    !!:  
          :!:           !:!   :!:        :!:      :!:  !:!  :!:    :!:  [0;1;30;94m
          ::: :::  :::: ::    ::        :: ::::  ::::: ::   ::     ::  
           :: :: :  :: : :     :        : :: : :   : :  :   :       :   [0;0m
'
sleep 1
}
function f_banner6 () {
echo '
        
                                .+o++////+osso-                          
           +-+-+-+-+-+-+-+    -yy/:::::://///odh:                        
           |c|S|p|l|o|i|t|   /Nsoooooso++oooooohMo                       
           +-+-+-+-+-+-+-+  /MNyy+/:/+hhyhyyyyhhMM+                      
                           `mMNh:-...-/mdo/--:+hMMN.                     
                           /MMMs-.``.mhhhs.```.:NMMo                     
                           yMMMh:-.`.oshys....:sMMMd                     
                          .NMMMMd/--:-----:::sdMMMMM-                    
                         :sMMMMd/---:::--::-../hMMMMs:`                  
                      `-oshMMNo.````.-::::-.```.+NMMh++-`                
                    ./shdNMMN/...................:NMMNdhs/.              
                   /hmmddMMMo.....................+MMMddmmh+             
                  `ys/.``NMN-----------------------mMM.`./sy.            
                         smd-----------------------hmy                   
                         `ys-:::::::::::::::::::::-oy.                   
                          .s///+////:::::::////+//:y-                    
                         `.-----://++//://+++/:----:.`                   
                        -:-.......://++:/+///-.......::`                 
                    `..:+/:::---::///+++++///::---:::///.``              
                   `.-://+++++++++oooossssooo+++++++++//:.`              
                     ````.......---------------.......````'
sleep 1
}
function f_banner7 () {
echo "
[0;31m
                  (                                   
                 )\ )           (                  ) [0;33m
                (()/(           )\         (    ( /(   
            (    /(_))  '  )   ((_)   (    )\   )\()) [0;1;30;94m
            )\  (_))    /(/(    _     )\  ((_) (_))/ 
           ((_) / __|  ((_)_\  | |   ((_)  (_) | |_  
          / _|  \__ \  | '_ \) | |  / _ \  | | |  _| 
          \__|  |___/  | .__/  |_|  \___/  |_|  \__| 
                       |_|                           [0;0m

"
sleep 1
}
function f_banner8 () {
echo "
                     [0;34m▄▄▄▄[0m              [0;37m▄▄▄▄[0m                   [0;1;30;90m██[0m              
                   [0;34m▄█▀▀▀[0;37m▀█[0m             [0;37m▀[0;1;30;90m▀██[0m                   [0;1;34;94m▀▀[0m       [0;1;34;94m█[0;34m█[0m     
          [0;34m▄█████[0;37m▄[0m  [0;37m██▄[0m       [0;37m██▄[0;1;30;90m███▄[0m     [0;1;30;90m██[0m       [0;1;34;94m▄████▄[0m    [0;1;34;94m████[0m     [0;34m███████[0m  
         [0;37m██▀[0m    [0;37m▀[0m   [0;37m▀███[0;1;30;90m█▄[0m   [0;1;30;90m██▀[0m  [0;1;30;90m▀██[0m    [0;1;34;94m██[0m      [0;1;34;94m██▀[0m  [0;1;34;94m▀█[0;34m█[0m     [0;34m██[0m       [0;34m█[0;37m█[0m     
         [0;37m██[0m             [0;1;30;90m▀██[0m  [0;1;30;90m██[0m    [0;1;34;94m██[0m    [0;1;34;94m██[0m      [0;34m██[0m    [0;34m██[0m     [0;34m██[0m       [0;37m██[0m     
         [0;1;30;90m▀██▄▄▄▄█[0m  [0;1;30;90m█▄▄▄▄[0;1;34;94m▄█▀[0m  [0;1;34;94m███▄▄██▀[0m    [0;34m██▄▄▄[0m   [0;34m▀██▄▄██[0;37m▀[0m  [0;37m▄▄▄██▄▄▄[0m    [0;37m█[0;1;30;90m█▄▄▄[0m  
           [0;1;30;90m▀▀▀▀▀[0m    [0;1;34;94m▀▀▀▀▀[0m    [0;1;34;94m██[0m [0;34m▀▀▀[0m       [0;34m▀▀▀▀[0m     [0;37m▀▀▀▀[0m    [0;37m▀▀▀▀▀[0;1;30;90m▀▀▀[0m     [0;1;30;90m▀▀▀▀[0m  
                             [0;34m██[0m                                               

"
sleep 1
}
bannernum=$(( $RANDOM % 8 + 1))
#echo "Banner: $bannernum"
f_banner"$bannernum"
echo "---------------------| [7;31mcyb3r gladiat0r's[7;37m Mass WHM/Cpanel[7;32m Pass Changer [0;0m |---------------------"
echo "      |                                                                            |"
echo "      |                                by: cyb3r gladiat0r                         |"
echo "      |                                                                            |"
echo "      | Select an option from the menu:                                            |"
echo "      |                                                                            |"
echo "      | 1. About Me                                                                |"
echo "      | 2. Read Me                                                                 |"
echo "      | 3. Credits                                                                 |"
echo "      | 4. Run the script                                                          |"
echo "      | X. Exit                                                                    |"
echo "      |                                                                            |"
echo "      ------------------------------------------------------------------------------"
while :
do
cat << !
!
echo
echo " Enter your choice: ";
read choice
echo
case $choice in

1) f_about ;;

2) f_readme ;;

3) f_credit ;;

4) f_launch ;;

X|x) exit ;;

*) echo "\"$choice\" is not valid "; sleep 2 ;;

esac

done
}

function f_about () {
echo "  
[0;30;94m  [---]          The cPanel Exploiter ([0;33mcSploit[0;30;94m)             [---]
  [---]     Written by: [0;31mHardeep Singh [0;30;94m([0;33mcyb3r gladiat0r[0;30;94m)     [---]
  [---]       Development Team: [0;31mInfi-Zeal[0;30;94m                   [---]
  [---]                Version: [0;31m$scriptversion[0;30;94m                         [---]
  [---]      Report [0;31mbugs[0;30;94m to: [0;32mcyb3r.gladiat0r@gmail.com[0;30;94m      [---]
  [---]    Subscribe me at Facebook: [0;35mwww.fb.com/h4rdeep[0;30;94m     [---]
  [---] Follow me on Twitter:[0;36mwww.twitter.com/cyb3rgladiat0r[0;30;94m [---]

   [0;32mWelcome to the cPanel Mass Password Changer (cPanel). Your one
    stop shop to reset all cPanel Accounts..[0;30;94m
    
    [1;37m--: (C) Copyright cyb3r gladiat0r [All rights reserved] :--[0;0m"
echo
echo "Press enter key to go to main menu."
read
f_menu
}

function f_readme () {
echo
echo "                  Read Me"
echo "      [0;33mcSploit - cyb3r gladiat0r's cPanel mass password changer.[0;30;35m"
echo 
echo "      Run this script, and get all cpanel users passwords changed"
echo "      and got them saved in a text file with their respective usernames."
echo
echo "      passwords.txt or your specified file name"
echo "      In manual method give file name to store usernames and passwords."
echo "      Provide length of the password"
echo "      Select type of password (Viz. Numeric, Alphabetic, Alphnumeric or Alphanumeric with symbols.[0;0m"
echo
echo
echo "   Press enter key to go to main menu."
read
f_menu
}

function f_credit () {
echo
echo "      [1;37m»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»"
echo "      [4;30;32mCredits:-[0;30;36m"
echo
echo "      r45c4l bro, you are my source of inspiration"
echo
echo "      error_1046, r8l35n4k, cyb3R_s3ur3 ..... "
echo
echo 
echo "      [4;30;33mGreets:-[0;30;36m"
echo
echo "      SuP3r_h4ck3r, my frnds and all indian haxors."
echo
echo "     [1;37m»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»»[0;0m"
echo
echo "   Press enter key to go to main menu."
read
f_menu
}

function f_launch () {
while :
do
cat << !
!
echo
echo " Select the method to change the passwords:                         ([1;37mRefer Read Me for details[0;0m)"
echo
echo "  1. Automatic"
echo "  2. Manual"
echo "  X. Return to main menu"
echo

read choice
echo
case $choice in

1) f_rand ;;

2) f_spec ;;

x|X) f_menu ;;

*) echo "\"$choice\" is not valid "; sleep 2 ;;

esac
done
}
function f_spec () {
echo
echo "      cSploit Pass Changer - Manual Option"
echo
echo "    Please enter the password you want to keep for every account."
echo
read pass
for user in `ls -l /var/cpanel/users | awk '{print $9}'`
do
echo "$user $pass" >> passwords.txt
/scripts/realchpass $user $pass				# change cpanel users password with random generated password
/scripts/ftpupdate							# sync FTP passwords also
/scripts/mysqlpasswd						# sync mysql passwords also
done
echo
echo "      All cpanel passwords have been changeed to $pass. "
echo "      and are saved in passwords.txt file."
echo
echo "Press any key to return to Main Menu.." 

read
f_menu
}
function f_rand () {
echo
echo "      cSploit Pass Changer - Random Option"
echo
echo "      Enter the name of file, having all usernames and passwords ."
read name
echo
echo "      Enter the length of password (Eg. 6, 8, 12 etc)"
read len
echo
echo " Select the type of passwords:"
echo
echo "  1. Numeric"
echo "  2. Alphabetic"
echo "  3. Aphanumeric"
echo "  4. Alphabetic + Symbols"
echo "  X. Return to main menu"
echo
read choice
echo
case $choice in

1) ch = 1 ;;

2) ch = 2 ;;

3) ch = 3 ;;

4) ch = 4 ;;

x|X) f_menu ;;

*) echo "\"$choice\" is not valid " ;;

esac
for user in `ls -l /var/cpanel/users | awk '{print $9}'`
do
pass[1]=`</dev/urandom tr -dc "0-9" | head -c$len`
pass[2]=`</dev/urandom tr -dc "A-Za-z" | head -c$len`
pass[3]=`</dev/urandom tr -dc "A-Za-z0-9" | head -c$len`
pass[4]=`</dev/urandom tr -dc "A-Za-z0-9[{(<*-/+.=_\|\\#!@$%^&-:;~>)}]" | head -c$len`

echo "$user ${pass[$ch]}" >> $name.txt

/scripts/realchpass $user $pass$ch  		# change cpanel users password with random generated password
/scripts/ftpupdate							# sync FTP passwords also
/scripts/mysqlpasswd						# sync mysql passwords also
done
echo >> $name.txt
echo
echo "      All cpanel passwords have been changed and are saved in $name.txt file."
echo
echo "Press any key to return to Main Menu.." 

read
f_menu
}
#f_echobreak
#bash banner.sh
f_menu
